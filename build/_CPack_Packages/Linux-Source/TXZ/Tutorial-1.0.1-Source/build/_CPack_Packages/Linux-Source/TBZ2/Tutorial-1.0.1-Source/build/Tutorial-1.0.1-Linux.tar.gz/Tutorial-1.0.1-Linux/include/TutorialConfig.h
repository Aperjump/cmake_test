// the configered options and settings for tutorial
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0
/* #undef HAVE_LOG */
/* #undef HAVE_EXP */
